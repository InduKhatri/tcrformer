This directory contains the negative control TCR sequences.
